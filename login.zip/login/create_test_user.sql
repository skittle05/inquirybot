-- Insert test user
INSERT INTO users (username, email, password, first_name, last_name)
VALUES ('testuser', 'trancem260@gmail.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Test', 'User'); 