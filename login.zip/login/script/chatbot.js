const readline = require('readline');

const qaData = [
  {
    question: "What is JavaScript?",
    answer: "JavaScript is a programming language used mainly for web development."
  },
  {
    question: "How does photosynthesis work?",
    answer: "Photosynthesis is the process by which green plants convert sunlight into chemical energy."
  },
  {
    question: "What is AI?",
    answer: "AI stands for Artificial Intelligence, which is the simulation of human intelligence in machines."
  }
];

function getAnswer(question) {
  const qLower = question.toLowerCase().trim();
  const match = qaData.find(qa => qa.question.toLowerCase() === qLower);
  return match ? match.answer : "Sorry, I don't understand that question.";
}

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

function askQuestion() {
  rl.question('Ask your question (or type "exit" to quit): ', (userQuestion) => {
    if (userQuestion.toLowerCase() === 'exit') {
      console.log('Goodbye!');
      rl.close();
      return;
    }
    const response = getAnswer(userQuestion);
    console.log('Bot:', response);
    askQuestion();
  });
}

console.log('Welcome to the FAQ Chatbot!');
askQuestion();